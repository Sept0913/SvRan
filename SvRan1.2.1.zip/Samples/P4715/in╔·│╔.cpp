#include <cstdio>
#include <cstdlib>
#include <ctime>

using namespace std;
inline unsigned int rnd(){
	static unsigned int seed = rand();
	seed ^= seed << 17, seed ^= seed >> 5, seed ^= seed << 23;
	return seed;
}
int cas, n, tmp;
int main(){
    srand(time(NULL));
    scanf("%d", &cas);
    for(int i = 1 ; i <= cas ; i++){
    	char s[100];
    	sprintf(s, "P4715_%d.in", i);
    	freopen(s, "w", stdout);
    	n=rnd() % 7 + 1;
    	printf("%d\n", n);
    	for(int j = 0 ; j < (1 << n) ; j++){
    		tmp = rnd() % 100000 + 1;
    		printf("%d", tmp);
    		if(j != (1 << n) - 1) printf(" ");
		}
	}
    return 0;
}
