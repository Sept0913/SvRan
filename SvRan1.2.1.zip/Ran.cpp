#include <cstdio>
#include <cstdlib>
#include <ctime>

using namespace std;
//Random number
//rnd() % n + k : The number will be in [k, k + n).
inline unsigned int rnd(){
	static unsigned int seed = rand();
	seed ^= seed << 17, seed ^= seed >> 5, seed ^= seed << 23;
	return seed;
}
//Series
void series(int n, int mod){
//To make a n numbers,the numbers are in [-mod,mod](Not 0).
	for(int i = 0; i < n ; i++){
		int tmp = rnd() % mod + 1;
		int flag = rnd() % 2;
		if(!flag) flag = -1;
		printf("%d", tmp * flag);
		if(i != n - 1) printf(" ");
	}
	return;
}
//Special String
#define SIZE 1010
char c[SIZE][SIZE]={"int","char","bool","long","short"};
//In the "" is the string,there are n ""s,like this is the n=5.
void Spe_Str(int n){
	printf("%s", c[rnd() % n]);
}
//Lowercase Only String
void Ran_Str(int lon){
	for(int i = 0 ; i < lon ; i++){
		printf("%c", (rnd() % 26 + 97));//Generate a lowercase only string. 
	}
}
int main(){
	srand(time(NULL));
	//something
	return 0;
}
