#include <bits/stdc++.h>
#include <windows.h>

using namespace std;
int cas;
int main(){
    while(1){
        ++cas;
		Sleep(50);
        system("data.exe");
        system("std.exe");
        system("test.exe");
        printf("-----------This is Test Case %d----------\n", cas);
        if(system("fc test.out test.ans")) system("pause");
    }
}
