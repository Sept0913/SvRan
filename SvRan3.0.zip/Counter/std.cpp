#include <cstdio>

using namespace std;
int main(){
	freopen("test.in", "r", stdin);
	freopen("test.ans", "w", stdout);
	
	return 0;
}
