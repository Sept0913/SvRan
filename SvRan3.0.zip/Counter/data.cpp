#include <cstdio>

using namespace std;
int main(){
	freopen("test.in", "w", stdout);
	
	return 0;
}
