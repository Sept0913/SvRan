#include <cstdio>

using namespace std;
int main(){
	freopen("test.in", "r", stdin);
	freopen("test.out", "w", stdout);
	
	return 0;
}
