data.exe 是数据生成器，std.exe 是暴力，test.exe 是要测的程序。

test.out 是要测的程序的输出文件，test.ans 是暴力的输出文件。