#include <cstdio>
#include <cstdlib>
#include <ctime>

using namespace std;
inline unsigned int rnd(){
	static unsigned int seed = rand();
	seed ^= seed << 17, seed ^= seed >> 5, seed ^= seed << 23;
	return seed;
}
int cas, mod;//cas is the number of the cases.
int main(){
    srand(time(NULL));
    scanf("%d %d", &cas, &mod);
    for(int i = 1 ; i <= cas ; i++){
    	char s[100];
    	sprintf(s, "P1001_%d.in", i);
    	freopen(s, "w", stdout);
        printf("%d %d", rnd() % mod, rnd() % mod);
	}
    return 0;
}
