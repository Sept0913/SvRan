Ran.cpp：随机生成的函数
Samples：指例子
1. P1001
2. CF1316A
3. P4715
Database：数据库
Counter：对拍器