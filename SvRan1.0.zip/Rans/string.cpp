#include <cstdio>
#include <ctime>
#include <cstdlib>
#include <iostream>
#include <cstring>

using namespace std;
inline unsigned int rnd(){
	static unsigned int seed=rand();
	seed^=seed<<17,seed^=seed>>5,seed^=seed<<23;
	return seed;
}
string Ran_Str(int lon){
	string s="";
	for(int i=0;i<lon;i++){
		s=s+(char)(rnd()%26+97);//Generate a lowercase only string. 
	}
	return s;
}
int main(){
	srand(time(NULL));
	int lon;
	cin>>lon;
	cout<<Ran_Str(lon);
	return 0;
}
