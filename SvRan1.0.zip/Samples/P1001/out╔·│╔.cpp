#include <cstdio>

using namespace std;
int cas;//cas is the number of the cases.
int main(){
    scanf("%d",&cas);
    for(int i=1;i<=cas;i++){
    	char in[100],out[100];
    	sprintf(in,"P1001_%d.in",i);
    	sprintf(out,"P1001_%d.out",i);
    	freopen(in,"r",stdin);
    	freopen(out,"w",stdout);
    	int a,b;
    	scanf("%d%d",&a,&b);
        printf("%d",a+b);
	}
    return 0;
} 
