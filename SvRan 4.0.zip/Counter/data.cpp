#include <bits/stdc++.h>

#define ll long long
#define N 1000000
using namespace std;
inline unsigned ll rnd(){
	static unsigned ll seed = rand();
	seed ^= seed << 17, seed ^= seed >> 5, seed ^= seed << 23;
	return seed;
}
int main(){
	freopen("test.in", "w", stdout);
	srand(time(0));
	printf("1\n");
	int n = rnd() % 600 + 1;
	printf("%d\n", n);
	int cnt = 0;
	for(int i = 1 ; i <= n ; i++){
		int r = rnd() % 2;
		if(r) cnt++;
		if(i == n && cnt == 0) r = 1;
		printf("%d", r);
	}
	return 0;
}
