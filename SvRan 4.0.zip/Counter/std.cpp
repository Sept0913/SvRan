#include <cstdio>
#include <algorithm>

#define N 500010
#define ll long long
#define INF 1e9
using namespace std;
int a[N];
int n, T;
void Sol(){
	scanf("%d", &T);
	for(int j = 1 ; j <= T ; j++){
		scanf("%d", &n);
		ll ans = 0;
		for(int i = 0 ; i < n ; i++)
			scanf("%1d", &a[i]);
		for(int i = 0 ; i < n ; i++){
			int t = INF;
			if(a[i] == 0){
				for(int k = i - 1 ; k >= 0 ; k--)
				    if(a[k]){
						t = i - k;
						break;
				    }
				for(int k = i + 1 ; k < n ; k++)
				    if(a[k]){
						t = min(t, k - i);
						break;
				    }
				ans += t;
			}
		}
		printf("Case #%d: %lld\n", j, ans);
	}
	return;
}
int main(){
	freopen("test.in", "r", stdin);
	freopen("test.ans", "w", stdout);
	Sol();
	return 0;
}
