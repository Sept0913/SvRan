#include <cstdio>

#define N 500010
#define ll long long
using namespace std;
int a[N];
int n, T;
ll mid(int k){
	if(k == 0) return 0;
	int p = k / 2;
	if(k % 2) return p * (p + 1) + p + 1;
	return p * (p + 1);
}
ll be(int k){
	if(k == 0) return 0;
	return k * (k + 1) / 2;
}
void Sol(){
	scanf("%d", &T);
	for(int j = 1 ; j <= T ; j++){
		scanf("%d", &n);
		int cnt = 0, len = 0;
		ll ans = 0;
		for(int i = 0 ; i < n ; i++){
			scanf("%1d", &a[i]);
			if(a[i]){
				if(cnt == 0) ans += be(len);
				else ans += mid(len);
				cnt++;
				len = 0;
			}
			else
				len++;
		}
		printf("Case #%d: %lld\n", j, ans + be(len));
	}
	return;
}
int main(){
	freopen("test.in", "r", stdin);
	freopen("test.out", "w", stdout);
	Sol();
	return 0;
}
