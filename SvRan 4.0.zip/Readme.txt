gen.cpp：随机生成的函数
std.cpp：是你的正解
maker.cpp：记得填写 ___ 和 *** 部分
Samples：指例子
1. P1001
2. CF1316A
3. P4715
Database：数据库
Counter：对拍器