#include <cstdio>
#include <windows.h>

using namespace std;
int main(){
	for(int i = 1 ; i <= ___ ; i++){
		char s[110], p[110];
		sprintf(s, "***_%d.out", i);
		sprintf(p, "***_%d.out", i);
		freopen(s, "r", stdin);
		freopen(p, "w", stdout);
		system("std.exe");
	}
	return 0;
}
