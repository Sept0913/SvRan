#include <cstdio>

using namespace std;
int lit(int a, int b){return a > b ? b : a;}
int t, tmp, sum = 0, n, m, cas;
int main(){
	scanf("%d", &cas);
	for(int k = 1 ; k <= cas ; k++){
        char in[100], out[100];
    	sprintf(in, "CF1316A_%d.in", k);
    	sprintf(out, "CF1316A_%d.out", k);
    	freopen(in, "r", stdin);
    	freopen(out, "w", stdout);
        scanf("%d", &t);
        while(t--){
            scanf("%d%d", &n, &m);
            sum = 0;
            for(int i = 0 ; i < n ; i++){
                scanf("%d", &tmp);
                sum += tmp;
            }
            printf("%d\n", lit(sum,m));
        }
    }
    return 0;
}
