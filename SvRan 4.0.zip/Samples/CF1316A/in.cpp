#include <cstdio>
#include <cstdlib>
#include <ctime>

using namespace std;
inline unsigned int rnd(){
	static unsigned int seed = rand();
	seed ^= seed << 17, seed ^= seed >> 5, seed ^= seed << 23;
	return seed;
}
int cas, t, n, tmp, m, mod;
int main(){
    srand(time(NULL));
    scanf("%d", &cas);
    for(int i = 1 ; i <= cas ; i++){
    	char s[100];
    	sprintf(s, "CF1316A_%d.in", i);
    	freopen(s, "w", stdout);
    	t = rnd() % 200 + 1;
    	printf("%d\n", t);
    	while(t--){
    		n = rnd() % 1000 + 1;
    		m = rnd() % 100000 + 1;
    		printf("%d %d\n", n, m);
    		for(int j = 0 ; j < n ; j++){
    			tmp = rnd() % (m + 1);
    			printf("%d", tmp);
    			if(j != n - 1) printf(" ");
			}
			puts("");
		}
	}
    return 0;
}
