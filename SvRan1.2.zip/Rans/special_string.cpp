#include <cstdio>
#include <ctime>
#include <cstdlib>

using namespace std;
#define SIZE 1010
inline unsigned int rnd(){
	static unsigned int seed=rand();
	seed^=seed<<17,seed^=seed>>5,seed^=seed<<23;
	return seed;
}
int n;
char c[SIZE][SIZE]={"int","char","bool","long","short"};
//In the "" is the string,there are n ""s,like this is the n=5.
int main(){
	srand(time(NULL));
	scanf("%d",&n);
	printf("%s",c[rnd()%n]);
	return 0;
}
