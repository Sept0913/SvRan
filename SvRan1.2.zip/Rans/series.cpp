#include <cstdio>
#include <cstdlib>
#include <ctime>

using namespace std;
inline unsigned int rnd(){
	static unsigned int seed=rand();
	seed^=seed<<17,seed^=seed>>5,seed^=seed<<23;
	return seed;
}
void series(int n,int mod){
	for(int i=0;i<n;i++){
		int tmp=rnd()%mod+1;
		int flag=rnd()%2;
		if(!flag) flag=-1;
		printf("%d",tmp*flag);
		if(i!=n-1) printf(" ");
	}
	return;
}
int main(){
	srand(time(NULL)); 
	int n,mod;
	scanf("%d%d",&n,&mod);
	series(n,mod);
	return 0;
}
