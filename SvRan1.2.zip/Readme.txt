Rans：指随机生成的函数
1. string.cpp
用于生成一个随机字符串（小写字符组成），输入的是需要生成的字符串的长度。
2. number.cpp
用于生成一个 n*m 的矩阵，需要输入 n,m,mod，mod表示生成数的范围为 [0,mod)。
3. special_string.cpp
用于在 n 个字符串中随机找到一个，适用于操作名称，需要输入 n，表示待选字符串个数。
4. series.cpp
用于生成一个长度为 n 的数列，且每个数的范围在 [-mod,mod] 中（非 0）。需要输入 n,mod。
Samples：指例子
1. P1001
2. CF1316A
3. P4715