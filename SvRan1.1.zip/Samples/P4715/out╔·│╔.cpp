#include <cstdio>
#include <queue>

using namespace std;
int n,tmp,cas;
struct Node{
	int num,ind;
};
int main(){
	scanf("%d",&cas);
	for(int k=1;k<=cas;k++){
        char in[100],out[100];
    	sprintf(in,"P4715_%d.in",k);
    	sprintf(out,"P4715_%d.out",k);
    	freopen(in,"r",stdin);
    	freopen(out,"w",stdout);
        queue <Node> q;
		scanf("%d",&n);
	    for(int i=0;i<(1<<n);i++){
		    scanf("%d",&tmp);
		    q.push((Node){tmp,i+1});
	    }
	    for(int i=n;i>1;i--){
		    for(int j=0;j<(1<<i);j+=2){
			    Node a=q.front();q.pop();
			    Node b=q.front();q.pop();
			    q.push((Node){a.num>b.num?a.num:b.num,a.num>b.num?a.ind:b.ind});
		    }
	    }
	    Node a=q.front();q.pop();
	    Node b=q.front();q.pop();
	    printf("%d",a.num<b.num?a.ind:b.ind);
	}
	
	return 0;
} 
