#include <cstdio>
#include <cstdlib>
#include <ctime>

using namespace std;
inline unsigned int rnd(){
	static unsigned int seed=rand();
	seed^=seed<<17,seed^=seed>>5,seed^=seed<<23;
	return seed;
}
int n,m,mod;
int main(){
    srand(time(NULL));
    scanf("%d%d%d",&n,&m,&mod);
    printf("%d\n",n);
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
        	int tmp=rnd()%mod;
        	printf("%d ",tmp);
		}
		puts("");
    }
    return 0;
}
